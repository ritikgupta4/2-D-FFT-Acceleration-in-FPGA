"""
File Name   : data_gen_fft.py
Author      : Avinash Sure
            : Nitin Chandrachoodan <nitin@ee.iitm.ac.in>

This program is used to generate random input data
and its corresponding FFT for a given length N.
"""

import numpy, random
import sys

def get_hex(value, fmt="{:04x}"):
	if value < 0:
		c = 2**16 + value
	else:
		c = value
	return fmt.format(c.astype(int))

def dump_coe(filename, x):
	with open(filename, "w") as f:
		for val in x[:-1]:
			dr = get_hex(val.real*(2**8))
			di = get_hex(val.imag*(2**8))
			f.write(di+dr+"\n")
		val = x[-1]
		dr = get_hex(val.real*(2**8))
		di = get_hex(val.imag*(2**8))
		f.write(di+dr+"\n")

if __name__ == "__main__" :
	
	# N = int(sys.argv[1])
	N = 32

	#numpy.random.seed(0)   # start from known state
	data1   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result1 = numpy.fft.fft(data1)
	numpy.savetxt("inp_cpp1.txt", data1, fmt = "%f %f")
	numpy.savetxt("out_cpp1.txt", result1, fmt = "%f %f")
	dump_coe("inp_hex1.mem", data1)
	dump_coe("out_hex1.mem", result1)
	
	data2  = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result2 = numpy.fft.fft(data2)
	numpy.savetxt("inp_cpp2.txt", data2, fmt = "%f %f")
	numpy.savetxt("out_cpp2.txt", result2, fmt = "%f %f")
	dump_coe("inp_hex2.mem", data2)
	dump_coe("out_hex2.mem", result2)
	
	data3   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result3 = numpy.fft.fft(data3)
	numpy.savetxt("inp_cpp3.txt", data3, fmt = "%f %f")
	numpy.savetxt("out_cpp3.txt", result3, fmt = "%f %f")
	dump_coe("inp_hex3.mem", data3)
	dump_coe("out_hex3.mem", result3)
	
	data4   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result4 = numpy.fft.fft(data4)
	numpy.savetxt("inp_cpp4.txt", data4, fmt = "%f %f")
	numpy.savetxt("out_cpp4.txt", result4, fmt = "%f %f")
	dump_coe("inp_hex4.mem", data4)
	dump_coe("out_hex4.mem", result4)
	
	data5   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result5 = numpy.fft.fft(data5)
	numpy.savetxt("inp_cpp5.txt", data5, fmt = "%f %f")
	numpy.savetxt("out_cpp5.txt", result5, fmt = "%f %f")
	dump_coe("inp_hex5.mem", data5)
	dump_coe("out_hex5.mem", result5)
	
	data6   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result6 = numpy.fft.fft(data6)
	numpy.savetxt("inp_cpp6.txt", data6, fmt = "%f %f")
	numpy.savetxt("out_cpp6.txt", result6, fmt = "%f %f")
	dump_coe("inp_hex6.mem", data6)
	dump_coe("out_hex6.mem", result6)
	
	data7  = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result7 = numpy.fft.fft(data7)
	numpy.savetxt("inp_cpp7.txt", data7, fmt = "%f %f")
	numpy.savetxt("out_cpp7.txt", result7, fmt = "%f %f")
	dump_coe("inp_hex7.mem", data7)
	dump_coe("out_hex7.mem", result7)
	
	data8   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result8 = numpy.fft.fft(data8)
	numpy.savetxt("inp_cpp8.txt", data8, fmt = "%f %f")
	numpy.savetxt("out_cpp8.txt", result8, fmt = "%f %f")
	dump_coe("inp_hex8.mem", data8)
	dump_coe("out_hex8.mem", result8)
	
	data9   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result9 = numpy.fft.fft(data9)
	numpy.savetxt("inp_cpp9.txt", data9, fmt = "%f %f")
	numpy.savetxt("out_cpp9.txt", result9, fmt = "%f %f")
	dump_coe("inp_hex9.mem", data9)
	dump_coe("out_hex9.mem", result9)
	
	data10   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result10 = numpy.fft.fft(data10)
	numpy.savetxt("inp_cpp10.txt", data10, fmt = "%f %f")
	numpy.savetxt("out_cpp10.txt", result10, fmt = "%f %f")
	dump_coe("inp_hex10.mem", data10)
	dump_coe("out_hex10.mem", result10)
	
	data11   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result11 = numpy.fft.fft(data11)
	numpy.savetxt("inp_cpp11.txt", data11, fmt = "%f %f")
	numpy.savetxt("out_cpp11.txt", result11, fmt = "%f %f")
	dump_coe("inp_hex11.mem", data11)
	dump_coe("out_hex11.mem", result11)
	
	data12  = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result12 = numpy.fft.fft(data12)
	numpy.savetxt("inp_cpp12.txt", data12, fmt = "%f %f")
	numpy.savetxt("out_cpp12.txt", result12, fmt = "%f %f")
	dump_coe("inp_hex12.mem", data12)
	dump_coe("out_hex12.mem", result12)
	
	data13   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result13 = numpy.fft.fft(data13)
	numpy.savetxt("inp_cpp13.txt", data13, fmt = "%f %f")
	numpy.savetxt("out_cpp13.txt", result13, fmt = "%f %f")
	dump_coe("inp_hex13.mem", data13)
	dump_coe("out_hex13.mem", result13)
	
	data14   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result14 = numpy.fft.fft(data14)
	numpy.savetxt("inp_cpp14.txt", data14, fmt = "%f %f")
	numpy.savetxt("out_cpp14.txt", result14, fmt = "%f %f")
	dump_coe("inp_hex14.mem", data14)
	dump_coe("out_hex14.mem", result14)
	
	data15   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result15 = numpy.fft.fft(data15)
	numpy.savetxt("inp_cpp15.txt", data15, fmt = "%f %f")
	numpy.savetxt("out_cpp15.txt", result15, fmt = "%f %f")
	dump_coe("inp_hex15.mem", data15)
	dump_coe("out_hex15.mem", result15)
	
	data16   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result16 = numpy.fft.fft(data16)
	numpy.savetxt("inp_cpp16.txt", data16, fmt = "%f %f")
	numpy.savetxt("out_cpp16.txt", result16, fmt = "%f %f")
	dump_coe("inp_hex16.mem", data16)
	dump_coe("out_hex16.mem", result16)
	
	data17  = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result17 = numpy.fft.fft(data17)
	numpy.savetxt("inp_cpp17.txt", data17, fmt = "%f %f")
	numpy.savetxt("out_cpp17.txt", result17, fmt = "%f %f")
	dump_coe("inp_hex17.mem", data17)
	dump_coe("out_hex17.mem", result17)
	
	data18   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result18 = numpy.fft.fft(data18)
	numpy.savetxt("inp_cpp18.txt", data18, fmt = "%f %f")
	numpy.savetxt("out_cpp18.txt", result18, fmt = "%f %f")
	dump_coe("inp_hex18.mem", data18)
	dump_coe("out_hex18.mem", result18)
	
	data19   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result19 = numpy.fft.fft(data19)
	numpy.savetxt("inp_cpp19.txt", data19, fmt = "%f %f")
	numpy.savetxt("out_cpp19.txt", result19, fmt = "%f %f")
	dump_coe("inp_hex19.mem", data19)
	dump_coe("out_hex19.mem", result19)
	
	data20   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result20 = numpy.fft.fft(data20)
	numpy.savetxt("inp_cpp20.txt", data20, fmt = "%f %f")
	numpy.savetxt("out_cpp20.txt", result20, fmt = "%f %f")
	dump_coe("inp_hex20.mem", data20)
	dump_coe("out_hex20.mem", result20)
	
	data21   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result21 = numpy.fft.fft(data21)
	numpy.savetxt("inp_cpp21.txt", data21, fmt = "%f %f")
	numpy.savetxt("out_cpp21.txt", result21, fmt = "%f %f")
	dump_coe("inp_hex21.mem", data21)
	dump_coe("out_hex21.mem", result21)
	
	data22  = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result22 = numpy.fft.fft(data22)
	numpy.savetxt("inp_cpp22.txt", data22, fmt = "%f %f")
	numpy.savetxt("out_cpp22.txt", result22, fmt = "%f %f")
	dump_coe("inp_hex22.mem", data22)
	dump_coe("out_hex22.mem", result22)
	
	data23   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result23 = numpy.fft.fft(data23)
	numpy.savetxt("inp_cpp23.txt", data23, fmt = "%f %f")
	numpy.savetxt("out_cpp23.txt", result23, fmt = "%f %f")
	dump_coe("inp_hex23.mem", data23)
	dump_coe("out_hex23.mem", result23)
	
	data24   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result24 = numpy.fft.fft(data24)
	numpy.savetxt("inp_cpp24.txt", data24, fmt = "%f %f")
	numpy.savetxt("out_cpp24.txt", result24, fmt = "%f %f")
	dump_coe("inp_hex24.mem", data24)
	dump_coe("out_hex24.mem", result24)
	
	data25   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result25 = numpy.fft.fft(data25)
	numpy.savetxt("inp_cpp25.txt", data25, fmt = "%f %f")
	numpy.savetxt("out_cpp25.txt", result25, fmt = "%f %f")
	dump_coe("inp_hex25.mem", data25)
	dump_coe("out_hex25.mem", result25)
	
	data26   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result26 = numpy.fft.fft(data26)
	numpy.savetxt("inp_cpp26.txt", data26, fmt = "%f %f")
	numpy.savetxt("out_cpp26.txt", result26, fmt = "%f %f")
	dump_coe("inp_hex26.mem", data26)
	dump_coe("out_hex26.mem", result26)
	
	data27  = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result27 = numpy.fft.fft(data27)
	numpy.savetxt("inp_cpp27.txt", data27, fmt = "%f %f")
	numpy.savetxt("out_cpp27.txt", result27, fmt = "%f %f")
	dump_coe("inp_hex27.mem", data27)
	dump_coe("out_hex27.mem", result27)
	
	data28   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result28 = numpy.fft.fft(data28)
	numpy.savetxt("inp_cpp28.txt", data28, fmt = "%f %f")
	numpy.savetxt("out_cpp28.txt", result28, fmt = "%f %f")
	dump_coe("inp_hex28.mem", data28)
	dump_coe("out_hex28.mem", result28)
	
	data29   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result29 = numpy.fft.fft(data29)
	numpy.savetxt("inp_cpp29.txt", data29, fmt = "%f %f")
	numpy.savetxt("out_cpp29.txt", result29, fmt = "%f %f")
	dump_coe("inp_hex29.mem", data29)
	dump_coe("out_hex29.mem", result29)
	
	data30   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result30 = numpy.fft.fft(data30)
	numpy.savetxt("inp_cpp30.txt", data30, fmt = "%f %f")
	numpy.savetxt("out_cpp30.txt", result30, fmt = "%f %f")
	dump_coe("inp_hex30.mem", data30)
	dump_coe("out_hex30.mem", result30)
	
	data31   = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result31 = numpy.fft.fft(data31)
	numpy.savetxt("inp_cpp31.txt", data31, fmt = "%f %f")
	numpy.savetxt("out_cpp31.txt", result31, fmt = "%f %f")
	dump_coe("inp_hex31.mem", data31)
	dump_coe("out_hex31.mem", result31)
	
	data32  = numpy.array([(numpy.random.randn()+1j*numpy.random.randn()) for i in range(N)])
	result32 = numpy.fft.fft(data32)
	numpy.savetxt("inp_cpp32.txt", data32, fmt = "%f %f")
	numpy.savetxt("out_cpp32.txt", result32, fmt = "%f %f")
	dump_coe("inp_hex32.mem", data32)
	dump_coe("out_hex32.mem", result32)
	
	
	
	

