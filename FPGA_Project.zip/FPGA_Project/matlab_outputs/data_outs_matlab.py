
import numpy, random
import sys

def get_hex(value, fmt="{:04x}"):
	if value < 0:
		c = 2**16 + value
	else:
		c = value
	return fmt.format(c.astype(int))

def dump_coe(filename, x):
	with open(filename, "w") as f:
		for val in x[:-1]:
			dr = get_hex(val.real*(2**8))
			di = get_hex(val.imag*(2**8))
			f.write(di+dr+"\n")
		val = x[-1]
		dr = get_hex(val.real*(2**8))
		di = get_hex(val.imag*(2**8))
		f.write(di+dr+"\n")

def transform_complex(line):
    return line.replace(b' ', b'').replace(b'+-', b'-').replace(b'i', b'j')

with open('out1.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr1 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr1)
    
with open('out2.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr2 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out3.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr3 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out4.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr4 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out5.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr5 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out6.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr6 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out7.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr7 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out8.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr8 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out9.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr9 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out10.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr10 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out11.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr11 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr1)
    
with open('out12.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr12 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out13.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr13 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out14.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr14 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out15.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr15 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out16.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr16 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out17.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr17 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out18.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr18 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out19.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr19 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out20.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr20 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out21.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr21 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr1)
    
with open('out22.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr22 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out23.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr23 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out24.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr24 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out25.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr25 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out26.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr26 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out27.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr27 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out28.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr28 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

with open('out29.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr29 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out30.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr30 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)
    
with open('out31.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr31 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr1)
    
with open('out32.txt', 'rb') as f:
    lines = map(transform_complex, f)
    arr32 = numpy.loadtxt(lines, dtype=numpy.complex128)
    #print(lines)
    #print(arr2)

dump_coe("out_hex1.mem", arr1)
dump_coe("out_hex2.mem", arr2)
dump_coe("out_hex3.mem", arr3)
dump_coe("out_hex4.mem", arr4)
dump_coe("out_hex5.mem", arr5)
dump_coe("out_hex6.mem", arr6)
dump_coe("out_hex7.mem", arr7)
dump_coe("out_hex8.mem", arr8)
dump_coe("out_hex9.mem", arr9)
dump_coe("out_hex10.mem", arr10)
dump_coe("out_hex11.mem", arr11)
dump_coe("out_hex12.mem", arr12)
dump_coe("out_hex13.mem", arr13)
dump_coe("out_hex14.mem", arr14)
dump_coe("out_hex15.mem", arr15)
dump_coe("out_hex16.mem", arr16)
dump_coe("out_hex17.mem", arr17)
dump_coe("out_hex18.mem", arr18)
dump_coe("out_hex19.mem", arr19)
dump_coe("out_hex20.mem", arr20)
dump_coe("out_hex21.mem", arr21)
dump_coe("out_hex22.mem", arr22)
dump_coe("out_hex23.mem", arr23)
dump_coe("out_hex24.mem", arr24)
dump_coe("out_hex25.mem", arr25)
dump_coe("out_hex26.mem", arr26)
dump_coe("out_hex27.mem", arr27)
dump_coe("out_hex28.mem", arr28)
dump_coe("out_hex29.mem", arr29)
dump_coe("out_hex30.mem", arr30)
dump_coe("out_hex31.mem", arr31)
dump_coe("out_hex32.mem", arr32)

